/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/projects_done/v_rgb2ycbcr_hdtv_async_top/v_rgb2ycbcr_hdtv_async_top_tb.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 0U};
static int ng3[] = {1, 0};
static int ng4[] = {16, 0};
static unsigned int ng5[] = {240U, 0U};
static unsigned int ng6[] = {1U, 0U};
static int ng7[] = {128, 0, 0, 0};
static int ng8[] = {235, 0};
static int ng9[] = {240, 0};
static int ng10[] = {4, 0};
static const char *ng11 = "\n error. r=%h, g=%h, b=%h, y_compute_sat_v = %h, ycbcr_data_op[23:16]=%h";
static const char *ng12 = "\n error. r=%h, g=%h, b=%h, cb_compute_sat_v = %h, ycbcr_data_op[15:8]=%h";
static const char *ng13 = "\n error. r=%h, g=%h, b=%h, cr_compute_sat_v = %h, ycbcr_data_op[7:0]=%h";
static const char *ng14 = "\nData check done! No errors found!";
static const char *ng15 = "\nBurst of 16 data check done! No data lose found!";



static void Initial_92_0(char *t0)
{
    char t6[8];
    char t15[8];
    char t17[8];
    char t27[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t16;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    double t40;
    double t41;
    double t42;
    double t43;
    double t44;
    double t45;
    double t46;
    double t47;
    double t48;
    double t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;

LAB0:    t1 = (t0 + 7576U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(92, ng0);

LAB4:    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(95, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(96, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 24);
    xsi_set_current_line(97, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3136);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(99, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(100, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3456);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3616);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(102, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(103, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3936);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(104, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4096);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(105, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4256);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(106, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 6656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(113, ng0);
    t2 = (t0 + 8640);
    *((int *)t2) = 1;
    t3 = (t0 + 7608);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(115, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 8656);
    *((int *)t2) = 1;
    t3 = (t0 + 7608);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(119, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(120, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 8672);
    *((int *)t2) = 1;
    t3 = (t0 + 7608);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(124, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(125, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3616);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(128, ng0);
    xsi_set_current_line(128, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4416);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB12:    t2 = (t0 + 4416);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB13;

LAB14:    xsi_set_current_line(138, ng0);
    t2 = (t0 + 8704);
    *((int *)t2) = 1;
    t3 = (t0 + 7608);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB18;
    goto LAB1;

LAB13:    xsi_set_current_line(128, ng0);

LAB15:    xsi_set_current_line(129, ng0);
    t13 = (t0 + 8688);
    *((int *)t13) = 1;
    t14 = (t0 + 7608);
    *((char **)t14) = t13;
    *((char **)t1) = &&LAB16;
    goto LAB1;

LAB16:    xsi_set_current_line(130, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB17;
    goto LAB1;

LAB17:    xsi_set_current_line(131, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 4416);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 3936);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(132, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4416);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 4096);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(133, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 4416);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 4256);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 8);
    xsi_set_current_line(134, ng0);
    t2 = (t0 + 4256);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t15, 0, 8);
    t5 = (t15 + 4);
    t7 = (t4 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 0);
    *((unsigned int *)t15) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t12 & 255U);
    t16 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t16 & 255U);
    t13 = (t0 + 4096);
    t14 = (t13 + 56U);
    t18 = *((char **)t14);
    memset(t17, 0, 8);
    t19 = (t17 + 4);
    t20 = (t18 + 4);
    t21 = *((unsigned int *)t18);
    t22 = (t21 >> 0);
    *((unsigned int *)t17) = t22;
    t23 = *((unsigned int *)t20);
    t24 = (t23 >> 0);
    *((unsigned int *)t19) = t24;
    t25 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t25 & 255U);
    t26 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t26 & 255U);
    t28 = (t0 + 3936);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memset(t27, 0, 8);
    t31 = (t27 + 4);
    t32 = (t30 + 4);
    t33 = *((unsigned int *)t30);
    t34 = (t33 >> 0);
    *((unsigned int *)t27) = t34;
    t35 = *((unsigned int *)t32);
    t36 = (t35 >> 0);
    *((unsigned int *)t31) = t36;
    t37 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t37 & 255U);
    t38 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t38 & 255U);
    xsi_vlogtype_concat(t6, 24, 24, 3U, t27, 8, t17, 8, t15, 8);
    t39 = (t0 + 2816);
    xsi_vlogvar_assign_value(t39, t6, 0, 0, 24);
    xsi_set_current_line(135, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 2976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 4416);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 4416);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB12;

LAB18:    xsi_set_current_line(139, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB19:    xsi_set_current_line(140, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(141, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 24);
    xsi_set_current_line(142, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3936);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(143, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4096);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(144, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4256);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(147, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4576);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(148, ng0);

LAB20:    t2 = (t0 + 1776U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t3 + 4);
    t8 = *((unsigned int *)t2);
    t9 = (~(t8));
    t10 = *((unsigned int *)t3);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB24;

LAB22:    if (*((unsigned int *)t2) == 0)
        goto LAB21;

LAB23:    t4 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t4) = 1;

LAB24:    t5 = (t6 + 4);
    t7 = (t3 + 4);
    t16 = *((unsigned int *)t3);
    t21 = (~(t16));
    *((unsigned int *)t6) = t21;
    *((unsigned int *)t5) = 0;
    if (*((unsigned int *)t7) != 0)
        goto LAB26;

LAB25:    t26 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t26 & 1U);
    t33 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t33 & 1U);
    t13 = (t6 + 4);
    t34 = *((unsigned int *)t13);
    t35 = (~(t34));
    t36 = *((unsigned int *)t6);
    t37 = (t36 & t35);
    t38 = (t37 != 0);
    if (t38 > 0)
        goto LAB27;

LAB28:    xsi_set_current_line(223, ng0);
    t2 = (t0 + 6656);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t13 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t5);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t7);
    t12 = *((unsigned int *)t13);
    t16 = (t11 ^ t12);
    t21 = (t10 | t16);
    t22 = *((unsigned int *)t7);
    t23 = *((unsigned int *)t13);
    t24 = (t22 | t23);
    t25 = (~(t24));
    t26 = (t21 & t25);
    if (t26 != 0)
        goto LAB114;

LAB111:    if (t24 != 0)
        goto LAB113;

LAB112:    *((unsigned int *)t6) = 1;

LAB114:    t18 = (t6 + 4);
    t33 = *((unsigned int *)t18);
    t34 = (~(t33));
    t35 = *((unsigned int *)t6);
    t36 = (t35 & t34);
    t37 = (t36 != 0);
    if (t37 > 0)
        goto LAB115;

LAB116:
LAB117:    xsi_set_current_line(228, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB119;
    goto LAB1;

LAB21:    *((unsigned int *)t6) = 1;
    goto LAB24;

LAB26:    t22 = *((unsigned int *)t6);
    t23 = *((unsigned int *)t7);
    *((unsigned int *)t6) = (t22 | t23);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t7);
    *((unsigned int *)t5) = (t24 | t25);
    goto LAB25;

LAB27:    xsi_set_current_line(148, ng0);

LAB29:    xsi_set_current_line(149, ng0);
    t14 = (t0 + 7384);
    xsi_process_wait(t14, 1000LL);
    *((char **)t1) = &&LAB30;
    goto LAB1;

LAB30:    xsi_set_current_line(150, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 3776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(151, ng0);
    t2 = (t0 + 8720);
    *((int *)t2) = 1;
    t3 = (t0 + 7608);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB31:    xsi_set_current_line(152, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB32;
    goto LAB1;

LAB32:    xsi_set_current_line(153, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 4576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 4736);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    xsi_set_current_line(154, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 4896);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    xsi_set_current_line(155, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 4576);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t2, 32, t5, 32);
    t7 = (t0 + 5056);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 4736);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t40 = xsi_vlog_convert_to_real(t4, 32, 1);
    t41 = (0.21299999999999999 * t40);
    t5 = (t0 + 4896);
    t7 = (t5 + 56U);
    t13 = *((char **)t7);
    t42 = xsi_vlog_convert_to_real(t13, 32, 1);
    t43 = (0.75100000000000000 * t42);
    t44 = (t41 + t43);
    t14 = (t0 + 5056);
    t18 = (t14 + 56U);
    t19 = *((char **)t18);
    t45 = xsi_vlog_convert_to_real(t19, 32, 1);
    t46 = (0.071999999999999995 * t45);
    t47 = (t44 + t46);
    xsi_vlog_convert_real_to_values(t47, t6, 32);
    t20 = (t0 + 5216);
    xsi_vlogvar_assign_value(t20, t6, 0, 0, 32);
    xsi_set_current_line(157, ng0);
    t2 = (t0 + 5056);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t40 = xsi_vlog_convert_to_real(t4, 32, 1);
    t41 = (0.51100000000000001 * t40);
    t5 = ((char*)((ng7)));
    t42 = xsi_vlog_convert_to_real(t5, 32, 1);
    t43 = (t41 + t42);
    t7 = (t0 + 4736);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    t44 = xsi_vlog_convert_to_real(t14, 32, 1);
    t45 = (0.11700000000000001 * t44);
    t46 = (t43 - t45);
    t18 = (t0 + 4896);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t47 = xsi_vlog_convert_to_real(t20, 32, 1);
    t48 = (0.39400000000000002 * t47);
    t49 = (t46 - t48);
    xsi_vlog_convert_real_to_values(t49, t6, 32);
    t28 = (t0 + 5376);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 32);
    xsi_set_current_line(158, ng0);
    t2 = (t0 + 4736);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t40 = xsi_vlog_convert_to_real(t4, 32, 1);
    t41 = (0.51100000000000001 * t40);
    t5 = ((char*)((ng7)));
    t42 = xsi_vlog_convert_to_real(t5, 32, 1);
    t43 = (t41 + t42);
    t7 = (t0 + 4896);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    t44 = xsi_vlog_convert_to_real(t14, 32, 1);
    t45 = (0.46400000000000002 * t44);
    t46 = (t43 - t45);
    t18 = (t0 + 5056);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t47 = xsi_vlog_convert_to_real(t20, 32, 1);
    t48 = (0.047000000000000000 * t47);
    t49 = (t46 - t48);
    xsi_vlog_convert_real_to_values(t49, t6, 32);
    t28 = (t0 + 5536);
    xsi_vlogvar_assign_value(t28, t6, 0, 0, 32);
    xsi_set_current_line(161, ng0);
    t2 = (t0 + 5216);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB33;

LAB34:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 5216);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB36;

LAB37:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 5216);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng8)));
    memset(t6, 0, 8);
    xsi_vlog_signed_greater(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB39;

LAB40:    xsi_set_current_line(168, ng0);
    t2 = (t0 + 5216);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 5696);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB41:
LAB38:
LAB35:    xsi_set_current_line(171, ng0);
    t2 = (t0 + 5376);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB42;

LAB43:    xsi_set_current_line(173, ng0);
    t2 = (t0 + 5376);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB45;

LAB46:    xsi_set_current_line(175, ng0);
    t2 = (t0 + 5376);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng9)));
    memset(t6, 0, 8);
    xsi_vlog_signed_greater(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB48;

LAB49:    xsi_set_current_line(178, ng0);
    t2 = (t0 + 5376);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 5856);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB50:
LAB47:
LAB44:    xsi_set_current_line(181, ng0);
    t2 = (t0 + 5536);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB51;

LAB52:    xsi_set_current_line(183, ng0);
    t2 = (t0 + 5536);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB54;

LAB55:    xsi_set_current_line(185, ng0);
    t2 = (t0 + 5536);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng9)));
    memset(t6, 0, 8);
    xsi_vlog_signed_greater(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB57;

LAB58:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 5536);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 6016);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB59:
LAB56:
LAB53:    xsi_set_current_line(191, ng0);
    t2 = (t0 + 5696);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1456U);
    t7 = *((char **)t5);
    memset(t6, 0, 8);
    t5 = (t6 + 4);
    t13 = (t7 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (t8 >> 16);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t13);
    t11 = (t10 >> 16);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t16 & 255U);
    memset(t15, 0, 8);
    t14 = (t4 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB61;

LAB60:    t18 = (t6 + 4);
    if (*((unsigned int *)t18) != 0)
        goto LAB61;

LAB64:    if (*((unsigned int *)t4) > *((unsigned int *)t6))
        goto LAB62;

LAB63:    t20 = (t15 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t15);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB65;

LAB66:    xsi_set_current_line(194, ng0);
    t2 = (t0 + 1456U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t4 = (t3 + 4);
    t8 = *((unsigned int *)t3);
    t9 = (t8 >> 16);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t4);
    t11 = (t10 >> 16);
    *((unsigned int *)t2) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 255U);
    t5 = (t0 + 5696);
    t7 = (t5 + 56U);
    t13 = *((char **)t7);
    memset(t15, 0, 8);
    xsi_vlog_unsigned_minus(t15, 32, t6, 32, t13, 32);
    t14 = (t0 + 6176);
    xsi_vlogvar_assign_value(t14, t15, 0, 0, 8);

LAB67:    xsi_set_current_line(197, ng0);
    t2 = (t0 + 5856);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1456U);
    t7 = *((char **)t5);
    memset(t6, 0, 8);
    t5 = (t6 + 4);
    t13 = (t7 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (t8 >> 8);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t13);
    t11 = (t10 >> 8);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t16 & 255U);
    memset(t15, 0, 8);
    t14 = (t4 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB69;

LAB68:    t18 = (t6 + 4);
    if (*((unsigned int *)t18) != 0)
        goto LAB69;

LAB72:    if (*((unsigned int *)t4) > *((unsigned int *)t6))
        goto LAB70;

LAB71:    t20 = (t15 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t15);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB73;

LAB74:    xsi_set_current_line(200, ng0);
    t2 = (t0 + 1456U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t4 = (t3 + 4);
    t8 = *((unsigned int *)t3);
    t9 = (t8 >> 8);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t4);
    t11 = (t10 >> 8);
    *((unsigned int *)t2) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 255U);
    t5 = (t0 + 5856);
    t7 = (t5 + 56U);
    t13 = *((char **)t7);
    memset(t15, 0, 8);
    xsi_vlog_unsigned_minus(t15, 32, t6, 32, t13, 32);
    t14 = (t0 + 6336);
    xsi_vlogvar_assign_value(t14, t15, 0, 0, 8);

LAB75:    xsi_set_current_line(203, ng0);
    t2 = (t0 + 6016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1456U);
    t7 = *((char **)t5);
    memset(t6, 0, 8);
    t5 = (t6 + 4);
    t13 = (t7 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (t8 >> 0);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t13);
    t11 = (t10 >> 0);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t16 & 255U);
    memset(t15, 0, 8);
    t14 = (t4 + 4);
    if (*((unsigned int *)t14) != 0)
        goto LAB77;

LAB76:    t18 = (t6 + 4);
    if (*((unsigned int *)t18) != 0)
        goto LAB77;

LAB80:    if (*((unsigned int *)t4) > *((unsigned int *)t6))
        goto LAB78;

LAB79:    t20 = (t15 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t15);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    if (t25 > 0)
        goto LAB81;

LAB82:    xsi_set_current_line(206, ng0);
    t2 = (t0 + 1456U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t4 = (t3 + 4);
    t8 = *((unsigned int *)t3);
    t9 = (t8 >> 0);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t4);
    t11 = (t10 >> 0);
    *((unsigned int *)t2) = t11;
    t12 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t12 & 255U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 255U);
    t5 = (t0 + 6016);
    t7 = (t5 + 56U);
    t13 = *((char **)t7);
    memset(t15, 0, 8);
    xsi_vlog_unsigned_minus(t15, 32, t6, 32, t13, 32);
    t14 = (t0 + 6496);
    xsi_vlogvar_assign_value(t14, t15, 0, 0, 8);

LAB83:    xsi_set_current_line(209, ng0);
    t2 = (t0 + 6176);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng10)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB85;

LAB84:    t13 = (t5 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB85;

LAB88:    if (*((unsigned int *)t4) > *((unsigned int *)t5))
        goto LAB86;

LAB87:    t18 = (t6 + 4);
    t8 = *((unsigned int *)t18);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB89;

LAB90:
LAB91:    xsi_set_current_line(213, ng0);
    t2 = (t0 + 6336);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng10)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB94;

LAB93:    t13 = (t5 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB94;

LAB97:    if (*((unsigned int *)t4) > *((unsigned int *)t5))
        goto LAB95;

LAB96:    t18 = (t6 + 4);
    t8 = *((unsigned int *)t18);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB98;

LAB99:
LAB100:    xsi_set_current_line(217, ng0);
    t2 = (t0 + 6496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng10)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB103;

LAB102:    t13 = (t5 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB103;

LAB106:    if (*((unsigned int *)t4) > *((unsigned int *)t5))
        goto LAB104;

LAB105:    t18 = (t6 + 4);
    t8 = *((unsigned int *)t18);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB107;

LAB108:
LAB109:    xsi_set_current_line(221, ng0);
    t2 = (t0 + 4576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 4576);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB20;

LAB33:    xsi_set_current_line(162, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 5696);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB35;

LAB36:    xsi_set_current_line(164, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 5696);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB38;

LAB39:    xsi_set_current_line(166, ng0);
    t13 = ((char*)((ng8)));
    t14 = (t0 + 5696);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB41;

LAB42:    xsi_set_current_line(172, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 5856);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB44;

LAB45:    xsi_set_current_line(174, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 5856);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB47;

LAB48:    xsi_set_current_line(176, ng0);
    t13 = ((char*)((ng9)));
    t14 = (t0 + 5856);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB50;

LAB51:    xsi_set_current_line(182, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 6016);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB53;

LAB54:    xsi_set_current_line(184, ng0);
    t13 = ((char*)((ng4)));
    t14 = (t0 + 6016);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB56;

LAB57:    xsi_set_current_line(186, ng0);
    t13 = ((char*)((ng9)));
    t14 = (t0 + 6016);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 32);
    goto LAB59;

LAB61:    t19 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB63;

LAB62:    *((unsigned int *)t15) = 1;
    goto LAB63;

LAB65:    xsi_set_current_line(192, ng0);
    t28 = (t0 + 5696);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 1456U);
    t32 = *((char **)t31);
    memset(t17, 0, 8);
    t31 = (t17 + 4);
    t39 = (t32 + 4);
    t26 = *((unsigned int *)t32);
    t33 = (t26 >> 16);
    *((unsigned int *)t17) = t33;
    t34 = *((unsigned int *)t39);
    t35 = (t34 >> 16);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t36 & 255U);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t37 & 255U);
    memset(t27, 0, 8);
    xsi_vlog_unsigned_minus(t27, 32, t30, 32, t17, 32);
    t50 = (t0 + 6176);
    xsi_vlogvar_assign_value(t50, t27, 0, 0, 8);
    goto LAB67;

LAB69:    t19 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB71;

LAB70:    *((unsigned int *)t15) = 1;
    goto LAB71;

LAB73:    xsi_set_current_line(198, ng0);
    t28 = (t0 + 5856);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 1456U);
    t32 = *((char **)t31);
    memset(t17, 0, 8);
    t31 = (t17 + 4);
    t39 = (t32 + 4);
    t26 = *((unsigned int *)t32);
    t33 = (t26 >> 8);
    *((unsigned int *)t17) = t33;
    t34 = *((unsigned int *)t39);
    t35 = (t34 >> 8);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t36 & 255U);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t37 & 255U);
    memset(t27, 0, 8);
    xsi_vlog_unsigned_minus(t27, 32, t30, 32, t17, 32);
    t50 = (t0 + 6336);
    xsi_vlogvar_assign_value(t50, t27, 0, 0, 8);
    goto LAB75;

LAB77:    t19 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB79;

LAB78:    *((unsigned int *)t15) = 1;
    goto LAB79;

LAB81:    xsi_set_current_line(204, ng0);
    t28 = (t0 + 6016);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 1456U);
    t32 = *((char **)t31);
    memset(t17, 0, 8);
    t31 = (t17 + 4);
    t39 = (t32 + 4);
    t26 = *((unsigned int *)t32);
    t33 = (t26 >> 0);
    *((unsigned int *)t17) = t33;
    t34 = *((unsigned int *)t39);
    t35 = (t34 >> 0);
    *((unsigned int *)t31) = t35;
    t36 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t36 & 255U);
    t37 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t37 & 255U);
    memset(t27, 0, 8);
    xsi_vlog_unsigned_minus(t27, 32, t30, 32, t17, 32);
    t50 = (t0 + 6496);
    xsi_vlogvar_assign_value(t50, t27, 0, 0, 8);
    goto LAB83;

LAB85:    t14 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB87;

LAB86:    *((unsigned int *)t6) = 1;
    goto LAB87;

LAB89:    xsi_set_current_line(209, ng0);

LAB92:    xsi_set_current_line(210, ng0);
    t19 = (t0 + 4736);
    t20 = (t19 + 56U);
    t28 = *((char **)t20);
    t29 = (t0 + 4896);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t0 + 5056);
    t39 = (t32 + 56U);
    t50 = *((char **)t39);
    t51 = (t0 + 5696);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t0 + 1456U);
    t55 = *((char **)t54);
    memset(t15, 0, 8);
    t54 = (t15 + 4);
    t56 = (t55 + 4);
    t16 = *((unsigned int *)t55);
    t21 = (t16 >> 16);
    *((unsigned int *)t15) = t21;
    t22 = *((unsigned int *)t56);
    t23 = (t22 >> 16);
    *((unsigned int *)t54) = t23;
    t24 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t24 & 255U);
    t25 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t25 & 255U);
    xsi_vlogfile_write(1, 0, 0, ng11, 6, t0, (char)119, t28, 32, (char)119, t31, 32, (char)119, t50, 32, (char)119, t53, 32, (char)118, t15, 8);
    xsi_set_current_line(211, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 6656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB91;

LAB94:    t14 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB96;

LAB95:    *((unsigned int *)t6) = 1;
    goto LAB96;

LAB98:    xsi_set_current_line(213, ng0);

LAB101:    xsi_set_current_line(214, ng0);
    t19 = (t0 + 4736);
    t20 = (t19 + 56U);
    t28 = *((char **)t20);
    t29 = (t0 + 4896);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t0 + 5056);
    t39 = (t32 + 56U);
    t50 = *((char **)t39);
    t51 = (t0 + 5856);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t0 + 1456U);
    t55 = *((char **)t54);
    memset(t15, 0, 8);
    t54 = (t15 + 4);
    t56 = (t55 + 4);
    t16 = *((unsigned int *)t55);
    t21 = (t16 >> 8);
    *((unsigned int *)t15) = t21;
    t22 = *((unsigned int *)t56);
    t23 = (t22 >> 8);
    *((unsigned int *)t54) = t23;
    t24 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t24 & 255U);
    t25 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t25 & 255U);
    xsi_vlogfile_write(1, 0, 0, ng12, 6, t0, (char)119, t28, 32, (char)119, t31, 32, (char)119, t50, 32, (char)119, t53, 32, (char)118, t15, 8);
    xsi_set_current_line(215, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 6656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB100;

LAB103:    t14 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB105;

LAB104:    *((unsigned int *)t6) = 1;
    goto LAB105;

LAB107:    xsi_set_current_line(217, ng0);

LAB110:    xsi_set_current_line(218, ng0);
    t19 = (t0 + 4736);
    t20 = (t19 + 56U);
    t28 = *((char **)t20);
    t29 = (t0 + 4896);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t0 + 5056);
    t39 = (t32 + 56U);
    t50 = *((char **)t39);
    t51 = (t0 + 6016);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t0 + 1456U);
    t55 = *((char **)t54);
    memset(t15, 0, 8);
    t54 = (t15 + 4);
    t56 = (t55 + 4);
    t16 = *((unsigned int *)t55);
    t21 = (t16 >> 0);
    *((unsigned int *)t15) = t21;
    t22 = *((unsigned int *)t56);
    t23 = (t22 >> 0);
    *((unsigned int *)t54) = t23;
    t24 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t24 & 255U);
    t25 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t25 & 255U);
    xsi_vlogfile_write(1, 0, 0, ng13, 6, t0, (char)119, t28, 32, (char)119, t31, 32, (char)119, t50, 32, (char)119, t53, 32, (char)118, t15, 8);
    xsi_set_current_line(219, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 6656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB109;

LAB113:    t14 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB114;

LAB115:    xsi_set_current_line(223, ng0);

LAB118:    xsi_set_current_line(225, ng0);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);
    xsi_set_current_line(226, ng0);
    xsi_vlogfile_write(1, 0, 0, ng15, 1, t0);
    goto LAB117;

LAB119:    xsi_set_current_line(229, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(231, ng0);
    t2 = (t0 + 7384);
    xsi_process_wait(t2, 1000000LL);
    *((char **)t1) = &&LAB120;
    goto LAB1;

LAB120:    xsi_set_current_line(232, ng0);
    xsi_vlog_stop(1);
    goto LAB1;

}

static void Always_236_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;

LAB0:    t1 = (t0 + 7824U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(236, ng0);

LAB4:    xsi_set_current_line(237, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(238, ng0);
    t2 = (t0 + 7632);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(238, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 2496);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(239, ng0);
    t2 = (t0 + 7632);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    goto LAB2;

}

static void Always_243_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;

LAB0:    t1 = (t0 + 8072U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(243, ng0);

LAB4:    xsi_set_current_line(244, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3136);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(245, ng0);
    t2 = (t0 + 7880);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(245, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 3136);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(246, ng0);
    t2 = (t0 + 7880);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    goto LAB2;

}

static void Always_250_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;

LAB0:    t1 = (t0 + 8320U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(250, ng0);

LAB4:    xsi_set_current_line(251, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3456);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(252, ng0);
    t2 = (t0 + 8128);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(252, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 3456);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(253, ng0);
    t2 = (t0 + 8128);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    goto LAB2;

}


extern void work_m_00000000000678155316_4034909776_init()
{
	static char *pe[] = {(void *)Initial_92_0,(void *)Always_236_1,(void *)Always_243_2,(void *)Always_250_3};
	xsi_register_didat("work_m_00000000000678155316_4034909776", "isim/v_rgb2ycbcr_hdtv_async_top_tb_isim_beh.exe.sim/work/m_00000000000678155316_4034909776.didat");
	xsi_register_executes(pe);
}
